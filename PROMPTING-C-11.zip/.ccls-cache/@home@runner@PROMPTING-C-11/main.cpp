#include <iostream>
#include <fstream>
#include <string>
#include <vector>

int main() {
  std::cout << "PROMPTING DVTC1.1\n";
  std::cout << "TERMINAL PROMPTER BOOTING                  \n";
  std::cout << "THIS PROGRAM IS NOT TO BE DISTRIBUTED TO ANYONE UNLESS   GIVEN PERMISSION BY THE CREATOR OF THIS PROGRAM\n";
using namespace std;

// Define the list of prompts
  // Create a vector of strings to store the lines of the script.
  vector<string> script;
  // Open the file containing the script.
  // Open the script file.
  ifstream scriptFile("script.txt");

  // Read the lines of the script into the vector.
  string line;
  while (getline(scriptFile, line)) {
    script.push_back(line);
  }
  
  // Close the script file.
  scriptFile.close();

  // Create a loop to display the lines of the script.
  int lineNumber = 1;
  for (string line : script) {
    // Display the line number and the line of the script.
    cout << lineNumber++ << ". " << line << endl;
  }

  return 0;
  //Line 37 Active Bug 03.15.24_PATCHED 03.15.24
  //std::cout << "THIS PROGRAM IS PROTECTED UNDER THE CREATIVE COMMONS NON COMMERCIAL LICENSE\n";
}
//DVT NOTES
//OVERALL SUCSSESFULL AND WILL MOVE ON TO 1.0
//1.0 WILL BE A REWRITE OF THE PROGRAM WITH A LOT OF NEW FEATURES

//CONFIDENTIALITY NOTES: THIS PROGRAM IS NOT TO BE DISTRIBUTED TO ANYONE UNLESS GIVEN PERMISSION BY THE CREATOR OF THIS PROGRAM


